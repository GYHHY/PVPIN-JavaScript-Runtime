package com.pvpin.xingchen.modifiers.event;

public class EventApi {
	public static EventAdapter createCustomEvent(String key, Object jsobject) {
		return new EventAdapter(key, jsobject);
	}
	
	public static EventAdapter createCustomCancellableEvent(String key, Object jsobject) {
		return new EventAdapterCancellable(key, jsobject);
	}
}
