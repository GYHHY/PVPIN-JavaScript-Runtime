package com.pvpin.xingchen.modifiers.event;

import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class EventAdapter extends Event {
	private static final HandlerList handlers = new HandlerList();
	
	private String key;
	private Object jsobject;
	
	public EventAdapter(String key, Object jsobject) {
		this.key = key;
		this.jsobject = jsobject;
	}
	
	@Override
	public HandlerList getHandlers() {
		return handlers;
	}
	
	public static HandlerList getHandlerList() {
	    return handlers;
	}

	public String getKey() {
		return this.key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public Object getJsobject() {
		return this.jsobject;
	}

	public void setJsobject(Object jsobject) {
		this.jsobject = jsobject;
	}
}
