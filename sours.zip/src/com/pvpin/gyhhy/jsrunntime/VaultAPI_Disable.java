/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pvpin.gyhhy.jsrunntime;

import org.bukkit.plugin.java.JavaPlugin;
import net.milkbowl.vault.Vault;
import org.bukkit.plugin.Plugin;
import org.bukkit.Server;
import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.OfflinePlayer;
/**
 *
 * @author Administrator
 */
public class VaultAPI_Disable {
    private static final Object economy = null;
    private static PVPIN plugin(){return PVPIN.plugin;}
    private static final Object vault = null;
    public static void onEnable(){}
    public PVPIN getPlugin(){
        return PVPIN.plugin;
    }
    private VaultAPI_Disable(){}
    public static Object give(OfflinePlayer op,double count){
        return null;
    }
    public static Object take(OfflinePlayer op,double count){
        return null;
    }
    public static Object getEconmoy(){return null;}
    public static double getBalance(OfflinePlayer op){
        return -1;
    }
    public static boolean isDisable(){return true;}
}
