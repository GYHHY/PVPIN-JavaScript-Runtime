/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pvpin.gyhhy.jsrunntime;
import com.pvpin.gyhhy.jsrunntime.util.GsonHelper;
import java.io.*;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author Administrator
 */
public final class Setting {
    public static void setOutputErrorMessage(boolean b){
        getSetting().Output_JavaScript_error_message = b;
    }
    public static boolean getOutputErrorMessage(){
        return getSetting().Output_JavaScript_error_message;
    }
    public static void setErrorDetails(boolean b){
        getSetting().errorDetails = b;
    }
    public static boolean getErrorDetails(){
        return getSetting().errorDetails;
    }
    private boolean Output_JavaScript_error_message = false,
            errorDetails = true;
    private static Setting set = null;
    public static Setting getSetting(){return set;}
    static void setSetting(Setting s){set = s;}
    public static void reprintSetting() throws FileNotFoundException, IOException{
        if (getSetting() == null){
            throw new java.lang.NullPointerException("No configuration object found");
        }
        FileOutputStream out = new FileOutputStream(json_file);
        PrintStream pr = new PrintStream(out);
        String json_string = GsonHelper.init_gson.toJson(getSetting().utf());
        pr.print(json_string);
        pr.close();
        //out.close();
    }
    public static final File json_file = new File(PVPIN.plugin.RootDirectory,"config.json");
    static {
        setSetting(new Setting());
        try {
            if (json_file.exists()) {
                if (json_file.isDirectory()) {
                    PVPIN.plugin.getLogger().log(Level.WARNING, "WARNING: \"config.json\" not a valid file!!");
                } else {
                    try {
                        FileReader reader = new FileReader(json_file);
                        Setting set = GsonHelper.gson.fromJson(reader, Setting.class);
                        setSetting(set.deutf());
                    } catch (FileNotFoundException ex) {
                        PVPIN.plugin.getLogger().log(Level.SEVERE, "Error: No file found! But isn't this impossible?");
                    }
                }
            } else {
                PVPIN.plugin.getLogger().log(Level.SEVERE, "Error: No configuration found! Now create new config to you.");
                reprintSetting();
            }
        } catch (Throwable e) {
            PVPIN.plugin.getLogger().log(Level.SEVERE,"Setting init error....");
            e.printStackTrace();
        }
    }

    private Setting utf() {
//        Setting s = new Setting();
//        s.log = log;
//        return s;
        return this;
    }
    /**
     * 只在加载配置时调用
     * public boolean load(){
     *   return true;
     * }
     */
    public boolean load(){
        return true;
    }
    private Setting deutf() {
        return this;
    }
}
