/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pvpin.gyhhy.jsrunntime.util;

import com.pvpin.gyhhy.jsrunntime.PVPIN;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.script.ScriptException;
import jdk.nashorn.api.scripting.NashornScriptEngine;
import jdk.nashorn.api.scripting.ScriptObjectMirror;

/**
 *
 * @author Administrator
 */
public class JavaScriptHelper {
    public static final NashornScriptEngine ev = PVPIN.plugin.getScriptEngine();
    public static final ScriptObjectMirror thr;
    static {
        ScriptObjectMirror m = null;
        try {
            m = (ScriptObjectMirror)ev.eval("(function(thr){throw thr})");
        } catch (Throwable ex) {
            PVPIN.plugin.getLogger().log(Level.SEVERE, null, ex);
        }
        thr = m;
    }
    public static void throwObject(Object QAQ){
        thr.call(null, QAQ);
    }
}
